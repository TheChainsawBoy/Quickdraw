import pygame
import os
import sys
import random
import threading
import time

# Initialize Pygame
pygame.init()

# Initialize the mixer for sound
pygame.mixer.init()

# Set up display
screen = pygame.display.set_mode((1000, 1000))
pygame.display.set_caption("Quickdraw")

# Global variables
IsFiring = False
can_fire = False

# Define paths for images
background_image_path = "__internal__/sp_BG.png"
player_image_paths = ["__internal__/sp_frame_0.png", "__internal__/sp_frame_1.png", "__internal__/sp_frame_2.png", "__internal__/sp_frame_3.png"]
dummy_image_path = "__internal__/sp_dummy.png"

# Load and scale the background image
background_image = pygame.image.load(background_image_path).convert_alpha()
background_image = pygame.transform.scale(background_image, (1000, 1000))

# Load and scale the player images
def load_and_scale_image(image_path, scale):
    image = pygame.image.load(image_path).convert_alpha()
    original_width, original_height = image.get_size()
    scaled_width = int(original_width * scale)
    scaled_height = int(original_height * scale)
    return pygame.transform.scale(image, (scaled_width, scaled_height))

# Load and scale all player images
player_images = [load_and_scale_image(path, scale=2.5) for path in player_image_paths]
player_image = player_images[0]  # Start with the first frame

# Load and scale dummy sprite
dummy_image = load_and_scale_image(dummy_image_path, scale=1.2)  # Increased size

# Animation parameters
speed = 0.6  # Speed of the slide-in animation
dummy_speed = random.uniform(3.5, 5.0)  # Speed of the dummy sprite movement
dummy_direction = 1  # 1 for right, -1 for left

# Define y-coordinate range for dummy sprite spawn
dummy_y_min = 380
dummy_y_max = 600

# Update dummy sprite position and size
dummy_width, dummy_height = dummy_image.get_size()
dummy_x = random.randint(0, screen.get_width() - dummy_width)
dummy_y = random.randint(dummy_y_min, dummy_y_max)  # Random y between specified range

# Score variable
score = 0

# Load and scale death animation frames
def load_and_scale_frames(folder, scale):
    frames = []
    for i in range(7):
        frame_path = os.path.join(folder, f"sp_frame_{i}.png")
        try:
            frame = pygame.image.load(frame_path).convert_alpha()
        except pygame.error as e:
            print(f"Unable to load image at {frame_path}: {e}")
            continue
        
        original_width, original_height = frame.get_size()

        # Calculate new dimensions based on the scale factor
        scaled_width = int(original_width * scale)
        scaled_height = int(original_height * scale)

        # Scale the frame and add to the list
        scaled_frame = pygame.transform.scale(frame, (scaled_width, scaled_height))
        frames.append(scaled_frame)
    
    return frames

death_anim_frames = load_and_scale_frames("__internal__", scale=2.5)

def time_count():
    """Draws the death animation frames sequentially"""
    global IsFiring
    IsFiring = True
    for frame in death_anim_frames:
        # Redraw the background to clear the previous frame
        screen.blit(background_image, (0, 0))
        screen.blit(dummy_image, (dummy_x, dummy_y))
        # Display each frame with a delay
        screen.blit(frame, (100, 500))
        pygame.display.flip()  # Update the screen with the new frame
        pygame.time.delay(80)  # Control the speed of the animation
    IsFiring = False

def update():
    """Update the enemy state"""
    time_count()

def dummy_anim():
    global dummy_x, dummy_direction
    while True:
        dummy_x += dummy_speed * dummy_direction
        if dummy_x <= 0 or dummy_x >= screen.get_width() - dummy_width:
            dummy_direction *= -1  # Change direction
        time.sleep(0.01)  # Control the speed of the dummy sprite movement

# Start the dummy animation thread
dummy_thread = threading.Thread(target=dummy_anim, daemon=True)
dummy_thread.start()

# Font for displaying score
font = pygame.font.Font(None, 36)

# Set initial player position off-screen
player_x = -700
player_y = 500

# Target position
target_x = 100
target_y = 500

# Game code
running = True
while running:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if can_fire:
                # Check if mouse is over the dummy sprite
                mouse_x, mouse_y = pygame.mouse.get_pos()
                if (dummy_x <= mouse_x <= dummy_x + dummy_width) and (dummy_y <= mouse_y <= dummy_y + dummy_height):
                    # Check if player sprite is "sp_frame_3.png"
                    if player_image == player_images[3]:  # Check if it's the 4th frame
                        score += 1
                        print(f"Score: {score}")
                update()

    # Slide-in animation for the player sprite
    if player_x < target_x:
        player_x += speed
        if player_x > target_x:
            player_x = target_x
            can_fire = True

    # Draw the background
    screen.blit(background_image, (0, 0))

    # Draw dummy sprite
    screen.blit(dummy_image, (dummy_x, dummy_y))

    # Draw player image
    if not IsFiring:
        screen.blit(player_image, (player_x, player_y))

    # Draw score
    score_text = font.render(f"Score: {score}", True, (255, 255, 255))
    screen.blit(score_text, (10, 10))  # Draw score in top-left corner

    # Update the display
    pygame.display.update()
